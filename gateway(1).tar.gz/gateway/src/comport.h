int SetComPort(int fd, int nSpeed, int nBits, char nEvent, int nStop);
