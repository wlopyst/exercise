struct CONFIG
{
	char output[100];//输出字符串
	unsigned int period;//时间间隔，单位为毫秒
	
	char DEVICE_NAME[100];
	char PRODUCT_ID[100];
	char DEVICE_SECRET[100];
};

int GetConfig(struct CONFIG *config); 
