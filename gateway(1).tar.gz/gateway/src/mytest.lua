local fs = require "nixio.fs"
m = Map("mytest", translate("测试"), translate("测试页面修改mytest软件包配置中产品名称，产品Id和产品密钥。"))
s = m:section(TypedSection, "mytest", "")
s.addremove = false
s.anonymous = true

view_output = s:option(TextValue, "DEVICE_NAME", "产品名称")
view_output.rmempty = false
view_output = s:option(TextValue, "PRODUCT_ID", "产品Id")
view_output.rmempty = false
view_output = s:option(TextValue, "DEVICE_SECRET", "产品密钥")
view_output.rmempty = false

m.on_after_commit = function(self)
	luci.sys.call("/etc/init.d/gateway restart > /dev/null")	
end
return m

