module("luci.controller.other",package.seeall)

function index()
	entry({"admin", "other"}, {}, _("其他"),60).index = true
	if nixio.fs.access("/etc/config/mytest") then
		entry({"admin", "other", "mytest"}, cbi("mytest"), _("测试"), 1)
	end
end	
